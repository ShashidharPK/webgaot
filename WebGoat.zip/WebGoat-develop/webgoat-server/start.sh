#!/bin/sh

java -jar -Djava.security.egd=file:/dev/./urandom /home/webgoat/webgoat.jar
